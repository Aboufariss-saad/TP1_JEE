package dao;

public interface VGA {
    void print (String message);
}
